/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex3Socket;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.function.Function;

/**
 *
 * @author josephawwal
 */
public class EchoS {
    
    private static HashMap<String, String> translate = new HashMap<>();
    
    
    private static HashMap<String, Function<String, String>> action = new HashMap<>();
    
    
    public static void main(String[] args) throws IOException {
        
        
        translate.put("hund", "dog");
        translate.put("cykel", "bike");
        translate.put("kylling", "chicken");
        translate.put("mand", "man");
        translate.put("kvinde", "woman");
        
        action.put("UPPER", (String x) -> { return x.toUpperCase();});
        action.put("LOWER", (String x) -> { return x.toLowerCase();});
        action.put("REVERSE", (String x) -> { return x.toUpperCase();});
        action.put("TRANSLATE", (String x) -> { return translate.get(x) == null ? "Not found" : translate.get(x);});

        
        
        EchoS server = new EchoS();
        server.run();
        
        
    }
    
    private final List<Socket> client = new ArrayList<>();
    
    private final int port = 1111;
    
    public void run() throws IOException {
        
        ServerSocket SS = new ServerSocket(port);
        System.out.println("Server init");
        
        
        while(true){
            
            Socket currentS = SS.accept();
            client.add(currentS);
            
            System.out.printf("IP: %s connected | Current client count: %d \n",currentS.getInetAddress(),client.size());
 
            new Thread( new Respond(currentS, client, action)).start();
        }
    }
}


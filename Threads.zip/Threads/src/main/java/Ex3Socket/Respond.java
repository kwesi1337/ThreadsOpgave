/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex3Socket;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

/**
 *
 * @author josephawwal
 */
public class Respond implements Runnable {
    
    private final Socket socket;
    private final List<Socket> client;
    private final Map<String, Function<String, String>> actions;
    
    public Respond(Socket socket, List<Socket> client, Map<String, Function<String, String>> actions){
        
        this.socket = socket;
        this.client = client;
        this.actions = actions;
        
        
        
    }
    
    @Override
    
    public void run(){
        
        try {
            InputStreamReader iStreamRead = new InputStreamReader(socket.getInputStream());
            BufferedReader br = new BufferedReader(iStreamRead);
            
            String input;
            
            while (!(input = br.readLine()).equals("close")){
                try
                {
                    String[] action = input.split("#");
                    String returnV = actions.get(action[0].toUpperCase()).apply(action[1]);
                    
                    

                    for (Socket sock : client){
                    PrintStream output = new PrintStream(sock.getOutputStream());
                    output.printf("Client %d: %\n", client.indexOf(socket) + 1, returnV);
                }
                    
                }
                catch (Exception e){
                    break;
                }
                
            }
            
            System.out.printf("Client %d: Disconnnect \n", client.indexOf(socket) + 1);
            
            client.remove(client.indexOf(socket));
            
        } catch (IOException e){
            
            System.out.println("Error");
        }
    }
}

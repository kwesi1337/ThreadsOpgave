/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex2;

import java.util.ArrayList;
import java.util.Arrays;
import static java.util.Collections.list;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author josephawwal
 */
public class WebTester {
    
    List<String> urls = Arrays.asList("https://fronter.com/cphbusiness/design_images/images.php/Classic/login/fronter_big-logo.png", 
            "https://fronter.com/cphbusiness/design_images/images.php/Classic/login/folder-image-transp.png",
            "https://fronter.com/volY12-cache/cache/img/design_images/Classic/other_images/button_bg.png");
    
    
    public void calcSizesParallel() throws InterruptedException {
        
        ExecutorService executor = Executors.newFixedThreadPool(urls.size());
        
        List<WebCalc> list = new ArrayList<>();
        
        
        for (String url : urls) {
            WebCalc calcs = new WebCalc(url);
            list.add(calcs);
            executor.submit(calcs);
            
            
        }
        
        executor.shutdown();
        executor.awaitTermination(10, TimeUnit.SECONDS);
    
    
    
    
    
  Optional<Integer> sum = list.stream().map(x -> x.getSum()).reduce((a, b) -> a + b);
        System.out.println(sum);
  
    }
    
    public void calcSizes() throws InterruptedException{
        
        List<WebCalc> list = new ArrayList<>();
        
        for (String url : urls){
            
            WebCalc calculator = new WebCalc(url);
            list.add(calculator);
            calculator.run();
            
            
        }
        
        Optional<Integer> sum = list.stream().map(x -> x.getSum()).reduce((a,b) -> a +b);
        System.out.println(sum);
        
        
    }
}



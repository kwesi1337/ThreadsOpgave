/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex2;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author josephawwal
 */
public class Exercise2 extends Thread implements Runnable {
    
    
    private long num;
    
    List<FibonacciObserver> observers = new ArrayList();
    
    
    public void registerFibonacciObserver(FibonacciObserver o){
        
        observers.add(o);
        
    }
    
    public Exercise2(long n){
        
        this.num = n;
        
    }
    
    
    public void run(){
        
        long numTemp = fib(num);
        
        for (FibonacciObserver observer : observers){
            observer.dataR(numTemp);
            
            
        }
    }
    
    private long fib(long n){
        
        if ((n == 0) || (n == 1)){
            
            return n;
            
            
        } else
        {
            return fib(n-1) + fib(n-2);
        }
    }
}

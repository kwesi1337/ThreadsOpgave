/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex2;

/**
 *
 * @author josephawwal
 */
public class Exercise1 {
 
    
    public static void main(String[] args) throws InterruptedException {
        
        System.out.println("Available proccs: " + Runtime.getRuntime().availableProcessors());
        
        WebTester tester = new WebTester();
        
        long begin = System.currentTimeMillis();
        tester.calcSizesParallel();
        
        long ending = System.currentTimeMillis();
        
        System.out.println("Time Par: " + (ending - begin));
        
        long begin2 = System.currentTimeMillis();
        tester.calcSizes();
        
        long ending2 = System.currentTimeMillis();
        
        System.out.println("Time Seq: " + (ending2 - begin2));
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ExamPrep2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.w3c.dom.css.Counter;

/**
 *
 * @author josephawwal
 */
public class Turn implements Runnable {

    BufferedReader reader;
    PrintStream write;
    Count count;

    public Turn(BufferedReader socket, PrintStream writer, Count count) {
        this.reader = socket;
        this.write = writer;
        this.count = count;
    }

    @Override
    public void run() {
        try {
            String type;
            while (!(type = reader.readLine()).equals("close")) {
                count.increment();
                write.println(count.getCounter());
                System.out.println(count.getCounter());
            }
        } catch (IOException ex) {
            Logger.getLogger(Turn.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}

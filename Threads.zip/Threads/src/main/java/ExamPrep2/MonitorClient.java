/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ExamPrep2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import static java.lang.System.out;
import java.net.Socket;

/**
 *
 * @author josephawwal
 */
public class MonitorClient {
    public static void main(String[] args) throws IOException {
        MonitorClient client = new MonitorClient();
        client.run();
    }
    
    private final int port = 1111;
    
    public void run() throws IOException {
        Socket sock = new Socket("localhost",port);
        out.printf("Connected #s \n",sock.getInetAddress());
                    
        InputStreamReader isr = new InputStreamReader(sock.getInputStream());
        BufferedReader br = new BufferedReader(isr);     
        
        

        PrintStream ps = new PrintStream(sock.getOutputStream());
        
        ps.println("Monitor");
        
        String input = null;
        while (!(input = br.readLine()).equals("Exit")) {
            System.out.println(input);
        }
        ps.println("close");
        sock.close();
        
    }
}

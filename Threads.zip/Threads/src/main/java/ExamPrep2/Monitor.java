/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ExamPrep2;

import java.io.PrintStream;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author joseph awwal
 */
public class Monitor implements Runnable {

    PrintStream write;
    Count count;

    public Monitor(PrintStream write, Count count) {
        this.write = write;
        this.count = count;
    }

    @Override
    public void run() {
        while (true) {
            try {
                write.println(count.getCounter());
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(Monitor.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}

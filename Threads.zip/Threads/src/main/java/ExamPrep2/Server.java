/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ExamPrep2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import org.w3c.dom.css.Counter;

/**
 *
 * @author josephawwal
 */
public class Server {

    public static void main(String[] args) throws IOException {
        Server server = new Server();
        server.run();
    }

    private final int port = 1111;
    private final Count count = new Count();

    public void run() throws IOException {
        ServerSocket SSocket = new ServerSocket(port);
        System.out.println("Server Started.");

        while (true) {
            Socket currentSocket = SSocket.accept();

            InputStreamReader isr = new InputStreamReader(currentSocket.getInputStream());
            BufferedReader br = new BufferedReader(isr);
            PrintStream ps = new PrintStream(currentSocket.getOutputStream());
            //Read first input to determinat type
            String type = br.readLine();

            if (type.equals("Turn")) {
                new Thread(new Turn(br,ps, count)).start();
            } else {
                new Thread(new Monitor(ps,count)).start();
            }
        }
    }
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex1;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author josephawwal
 */
public class ex2 extends Thread {
    
    public Even even;
    public int count;
    
 
    
    public ex2(Even ev1){
       
     even = ev1;
     
        
    }
    
    @Override
    public void run() {
         //To change body of generated methods, choose Tools | Templates.
       for(int i = 0; i < 1000000; i++){
                    
           
           System.out.println(even.next());
                   
       }
       
       
    }

    
    

    }


            


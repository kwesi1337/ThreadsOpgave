/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex1;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author josephawwal
 */
 public class ex1 extends Thread {
    
     public static class Thread1 extends Thread{
         
         long sum = 0;
         
         public void run(){
             
             try{
             
             for(long i = 0; i < 1000000000; i++){
                 
                 sum += i;
                 System.out.println("Thread: " + sum);
                 Thread.sleep(50);
             
         }
             }
             catch (InterruptedException e){
                 System.out.println("Thread interrupted");
             }
     }
     }
         
         
         public static class Thread2 extends Thread{
             
             
             public void run(){
             
             try {
             for(int i = 1; i < 6; i++){
                 
                
                 
                 System.out.println(i);
                 
                 Thread2.sleep(2000);
             }
             
             
         } catch (InterruptedException e){
             
                     System.out.println("");
             
         }
             
         }
     
     
     
    
         }
         
         public static class Thread3 extends Thread{
         int count = 10;
         
         boolean finish = false;
             public void run(){
                 
                
                   
                 
                 
               while(true)
               {
                   count++;
                   
                   System.out.println(count);
                     try { 
                                  Thread3.sleep(3000);
                     }   
                  
                     catch(InterruptedException e){
                 e.printStackTrace();
             }

               }
               
               
             
            
         }
             }
             
     
 
     public static void main(String[] args) {
         
         Thread1 t1 = new Thread1();
         Thread2 t2 = new Thread2();
         Thread3 t3 = new Thread3();
         
         
        new Thread1().start();
          new Thread2().start();
       new Thread3().start();
       
         try {
             Thread.sleep(10000);
         } catch (InterruptedException ex) {
             Logger.getLogger(ex1.class.getName()).log(Level.SEVERE, null, ex);
         }
         
         t3.finish=true;
         
         
         
     }
 }
 

 





    



    
    

    








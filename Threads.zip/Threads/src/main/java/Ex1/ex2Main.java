/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex1;

/**
 *
 * @author josephawwal
 */
public class ex2Main {
    
    public static void main(String[] args) {
    
        Even ev1 = new Even();
        
        
    ex2 t1 = new ex2(ev1); 
    
    ex2 t2 = new ex2(ev1);
    
    t1.start();
    t2.start();

    }
    
    
}
